

function a() {
    //取Input的Id(<input id="text1" type="text">)
    var input = document.getElementById('text1');
    //取Input的value放入submitBtn裡面
    var submitBtn = input.value;

    if (submitBtn == "") {
        return alert('請輸入文字!');
    }
    //取ol的id(    <ol id="ol1">
    //              <li>刷牙</li>
    //              <li>洗臉</li>
    //              <li>換衣服</li>
    //            </ol>                  )
    //取ol的Id,放入list變數裡面
    var list = document.getElementById('ol1');
    //建立一個新的li,但裡面還沒有內容
    var newLi = document.createElement("li");
    //新增li裡面的內容(內容為在Input輸入的文字)
    //newLi.textContent=`這是第${submitBtn}個LI`

    newLi.innerHTML = `<label>${submitBtn}</label>
                     <button class="btn-delete">刪除</button>`
    //將建立的li,並且是有我們輸入的內容,塞入ol(list)裡面
    list.appendChild(newLi);

    input.value = "";

}


document.querySelector('#ol1').addEventListener('click', function (event) {

    if (event.target.classList.contains('btn-delete')) {
        event.target.parentNode.remove();
    }
});









